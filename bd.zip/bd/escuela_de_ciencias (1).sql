-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 14, 2020 at 09:52 AM
-- Server version: 8.0.21-0ubuntu0.20.04.4
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `escuela_de_ciencias`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumno`
--

CREATE TABLE `alumno` (
  `Matricula_Alumno` int NOT NULL,
  `Nombre` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_P` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_M` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Curp` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Licenciatura` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Anio_Ingreso` int NOT NULL,
  `Semestre_Real` int NOT NULL,
  `Semestre_Actual` int NOT NULL,
  `Ciclo_Escolar` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Estatus_Carga` tinyint NOT NULL DEFAULT '0' COMMENT '1: carga materias 0:sin carga'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `alumno`
--

INSERT INTO `alumno` (`Matricula_Alumno`, `Nombre`, `Apellido_P`, `Apellido_M`, `Curp`, `Licenciatura`, `Anio_Ingreso`, `Semestre_Real`, `Semestre_Actual`, `Ciclo_Escolar`, `Estatus_Carga`) VALUES
(47856, 'Samuel', 'Aquino', 'Peralta', 'AUTT920610HOCGLM02', 'COMPUTACION', 2015, 8, 8, '2019-2019', 1),
(52532, 'José', 'Antonio', 'Perez', 'AUTT920610HOCGLM02', 'COMPUTACIÓN', 2015, 1, 1, '2015', 0),
(52743, 'Maria Eugenia', 'Jimenez', 'Garcia', 'JIGE950702MOCMRG07', 'COMPUTACION', 2015, 8, 8, '2019-2019', 1),
(52863, 'Jose Manuel', 'Garcia', 'Garcia', 'AUTT920610HOCGLM02', 'COMPUTACION', 2015, 8, 8, '2019-2019', 1),
(85639, 'Jesus David', 'Aquino', 'Rojas', 'AUTT920610HOCGLM02', 'COMPUTACION', 2015, 8, 8, '2019-2019', 1),
(93963, 'Tomás Antonio', 'Aguilar', 'Toledo', 'AUTT920610HOCGLM02', 'COMPUTACION', 2015, 8, 8, '2019-2019', 1);

-- --------------------------------------------------------

--
-- Table structure for table `aulas`
--

CREATE TABLE `aulas` (
  `Id_Aula` int NOT NULL,
  `Nombre_Aula` varchar(50) NOT NULL,
  `Disponible` tinyint NOT NULL COMMENT '1: disponible 0:No disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aulas`
--

INSERT INTO `aulas` (`Id_Aula`, `Nombre_Aula`, `Disponible`) VALUES
(1, 'Aula 1', 1),
(2, 'Lab. Computación', 1),
(3, 'Lab. Electronica', 1);

-- --------------------------------------------------------

--
-- Table structure for table `calificaciones_alumno`
--

CREATE TABLE `calificaciones_alumno` (
  `Matricula_Alumno` int NOT NULL,
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `CalificacionFinal` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `control_semestre`
--

CREATE TABLE `control_semestre` (
  `Id_semestre` int NOT NULL,
  `Inicio_Semestre` date NOT NULL,
  `Termino_Semestre` date NOT NULL,
  `Ciclo_Escolar` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Subida_Calif` date NOT NULL,
  `Limite_Subida` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `control_semestre`
--

INSERT INTO `control_semestre` (`Id_semestre`, `Inicio_Semestre`, `Termino_Semestre`, `Ciclo_Escolar`, `Subida_Calif`, `Limite_Subida`) VALUES
(1, '2019-09-23', '2019-09-24', '2019-2019', '2019-09-28', '2019-09-26');

-- --------------------------------------------------------

--
-- Table structure for table `docente`
--

CREATE TABLE `docente` (
  `Id_Docente` int NOT NULL,
  `Nombre_Docente` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_P` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_M` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Licenciatura` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `docente`
--

INSERT INTO `docente` (`Id_Docente`, `Nombre_Docente`, `Apellido_P`, `Apellido_M`, `Licenciatura`) VALUES
(1, 'Ishtar Gemma', 'Hernadez', 'Calvo', 'COMPUTACION'),
(2, 'Jorge', 'Cruz', 'Perez', 'COMPUTACION');

-- --------------------------------------------------------

--
-- Table structure for table `grupos`
--

CREATE TABLE `grupos` (
  `Id_grupo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Id_Docente` int NOT NULL,
  `Aula` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Capacidad` int NOT NULL,
  `Estatus_Grupo` smallint NOT NULL DEFAULT '1' COMMENT '1 = Disponible 2= Bloqueado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `grupos`
--

INSERT INTO `grupos` (`Id_grupo`, `Matricula_Materia`, `Id_Docente`, `Aula`, `Capacidad`, `Estatus_Grupo`) VALUES
('AAM13/9/2020/4:29:22', 'AAM-M', 1, '1', 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `grupo_alumno`
--

CREATE TABLE `grupo_alumno` (
  `Id_grupo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Matricula_Alumno` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `grupo_alumno`
--

INSERT INTO `grupo_alumno` (`Id_grupo`, `Matricula_Alumno`) VALUES
('AAM13/9/2020/4:29:22', 93963);

-- --------------------------------------------------------

--
-- Table structure for table `kardex_alumno`
--

CREATE TABLE `kardex_alumno` (
  `Id_kardex` int NOT NULL,
  `Matricula_Alumno` int NOT NULL,
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Calificacion` varchar(5) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Semestre` int NOT NULL,
  `Periodo_Lectivo` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Fecha_Examen` date NOT NULL,
  `Tipo_Examen` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Ciclo_Escolar` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `kardex_alumno`
--

INSERT INTO `kardex_alumno` (`Id_kardex`, `Matricula_Alumno`, `Matricula_Materia`, `Calificacion`, `Semestre`, `Periodo_Lectivo`, `Fecha_Examen`, `Tipo_Examen`, `Ciclo_Escolar`) VALUES
(1, 93963, 'MAM-1M', '6', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-07', 'ORDINARIO', '2015-2016'),
(2, 93963, 'EDM-M', '8', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-11', 'ORDINARIO', '2015-2016'),
(3, 93963, 'ICP-M', '10', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-06', 'ORDINARIO', '2015-2016'),
(4, 93963, 'COE-M', '8', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-08', 'ORDINARIO', '2015-2016'),
(5, 52743, 'MAM-1M', '5', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-07', 'ORDINARIO', '2015-2016'),
(6, 52743, 'EDM-M', '7', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-11', 'ORDINARIO', '2015-2016'),
(7, 52743, 'ICP-M', '7', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-06', 'ORDINARIO', '2015-2016'),
(8, 52743, 'CEA-M', '7', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-05', 'ORDINARIO', '2015-2016'),
(9, 52743, 'COE-M', '8', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-08', 'ORDINARIO', '2015-2016'),
(10, 52743, 'MAM-1M', '10', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-30', 'ORDINARIO', '2016-2016'),
(11, 52743, 'ALM-M', '9', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-22', 'ORDINARIO', '2016-2016'),
(12, 52743, 'FPP-M', '10', 2, 'FEBRERO 2016 - JULIO 2016', '2016-07-01', 'ORDINARIO', '2016-2016'),
(13, 52743, 'DSE-M', '10', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-20', 'ORDINARIO', '2016-2016'),
(14, 52743, 'IBE-M', '8', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-24', 'ORDINARIO', '2016-2016'),
(15, 52743, 'EDA-M', '10', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-21', 'ORDINARIO', '2016-2016'),
(16, 52743, 'DHE-M', '10', 2, 'FEBRERO 2016 - JULIO 2016', '2016-06-20', 'ORDINARIO', '2016-2016'),
(17, 93963, 'CEA-M', '6', 1, 'AGOSTO 2015 - ENERO 2016', '2016-01-05', 'ORDINARIO', '2015-2016'),
(18, 52743, 'MAM-2M', '8', 3, 'AGOSTO 2016-ENERO-2017', '2017-01-20', 'ORDINARIO', '2016-2017'),
(19, 52743, 'MDM-M', '9', 3, 'AGOSTO 2016-ENERO 2017', '2017-01-16', 'ORDINARIO', '2016-2017'),
(20, 52743, 'EDP-M', '10', 3, 'AGOSTO 2016-ENERO-2017', '2017-01-09', 'ORDINARIO', '2016-2017'),
(21, 52743, 'PRP-1M', 'NP', 3, 'AGOSTO 2016-ENERO 2017', '2017-01-12', 'ORDINARIO', '2016-2017'),
(22, 52743, 'FBT-M', '10', 3, 'AGOSTO 2016-ENERO 2017 ', '2017-01-11', 'ORDINARIO', '2016-2017'),
(23, 52743, 'IEE-M', '9', 3, 'AGOSTO 2016-ENERO 2017', '2017-01-19', 'ORDINARIO', '2016-2017'),
(24, 52743, 'MAM-3M', 'SD', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-21', 'ORDINARIO', '2017-2017'),
(25, 52743, 'PEM-M', '7', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-19', 'ORDINARIO', '2017-2017'),
(26, 52743, 'BAT-M', '8', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-28', 'ORDINARIO', '2017-2017'),
(27, 52743, 'SOT-M', '10', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-20', 'ORDINARIO', '2017-2017'),
(28, 52743, 'ACA-M', '8', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-22', 'ORDINARIO', '2017-2017'),
(29, 52743, 'IPE-M', '10', 4, 'FEBRERO 2017-JULIO 2017', '2017-06-23', 'ORDINARIO', '2017-2017'),
(30, 52743, 'PRP-1M', '9', 5, 'AGOSTO 2017-FEBRERO 2018', '2018-01-10', 'ORDINARIO', '2017-2018'),
(31, 52743, 'PWP-M', '9', 5, 'AGOSTO 2017-FEBRERO 2018', '2018-01-05', 'ORDINARIO', '2017-2018'),
(32, 52743, 'RCA-M', '10', 5, 'AGOSTO 2017-FEBRERO 2018', '2018-01-03', 'ORDINARIO', '2017-2018'),
(33, 52743, 'IIE-M', '8', 5, 'AGOSTO 2017-FEBRERO 2018', '2018-01-08', 'ORDINARIO', '2017-2018'),
(34, 52743, 'TAM-M', '7', 5, 'AGOSTO 2017-FEBRERO 2018', '2018-01-10', 'ORDINARIO', '2017-2018'),
(35, 52743, 'PRP-2M', '9', 6, 'FEBRERO 2018-JULIO 2018', '2018-06-28', 'ORDINARIO', '2018-2018'),
(36, 52743, 'AAM-M', '9', 6, 'FEBRERO 2018-JULIO 2018', '2018-06-21', 'ORDINARIO', '2018-2018'),
(37, 52743, 'ISP-M', '9', 6, 'AGOSTO 2018-JULIO 2018', '2018-06-22', 'ORDINARIO', '2018-2018'),
(38, 52743, 'SDA-M', '8', 6, 'AGOSTO 2018-JULIO 2018', '2018-06-25', 'ORDINARIO', '2018-2018'),
(40, 52743, 'MIE-M', '9', 6, 'AGOSTO 2018-JULIO 2018', '2018-06-20', 'ORDINARIO', '2018-2018'),
(41, 52743, 'IAE-M', '9', 6, 'AGOSTO 2018-JULIO 2018', '2018-06-27', 'ORDINARIO', '2018-2018'),
(42, 52743, 'MAM-3M', '7', 6, 'AGOSTO 2018-JULIO 2018', '2018-06-18', 'ORDINARIO', '2018-2018'),
(43, 52863, 'AAM-M', '7', 5, 'AGOSTO 2015-ENERO 2016', '2019-10-01', 'ORDINARIO', '2015 - 2016'),
(44, 52863, 'ACA-M', 'NP', 2, 'AGOSTO 2015-ENERO 2016', '2019-10-02', 'EXTRA-ORDINARIO', '2015-2016');

-- --------------------------------------------------------

--
-- Table structure for table `materias`
--

CREATE TABLE `materias` (
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Nombre` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Creditos` int NOT NULL,
  `Licenciatura` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Semestre` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `materias`
--

INSERT INTO `materias` (`Matricula_Materia`, `Nombre`, `Creditos`, `Licenciatura`, `Semestre`) VALUES
('AAM-M', 'Analisis de Algoritmos ', 10, 'COMPUTACION', 5),
('ACA-M', 'Arquitectura de Computadoras', 9, 'COMPUTACION', 4),
('ALM-M', 'Algebra Lineal', 10, 'COMPUTACION', 2),
('BAT-M', 'Base de Datos', 10, 'COMPUTACION', 4),
('BDT-M', 'Bases de Datos Distribuidas', 10, 'COMPUTACION', 7),
('CEA-M', 'Circuitos Electricos y Electronicos', 10, 'COMPUTACION', 1),
('COE-M', 'Comunicacion Oral y Escrita', 7, 'COMPUTACION', 1),
('COT-M', 'Compiladores', 10, 'COMPUTACION', 8),
('DHE-M', 'Derechos Humanos y Etica Profecional', 7, 'COMPUTACION', 5),
('DSE-M', 'Desarrollo Sustentable', 7, 'COMPUTACION', 2),
('EDA-M', 'Electronica Digital', 10, 'COMPUTACION', 3),
('EDM-M', 'Estructuras Discretas', 10, 'COMPUTACION', 1),
('EDP-M', 'Estructura de Datos', 10, 'COMPUTACION', 3),
('FBT-M', 'Fundamentos de Bases de Datos', 10, 'COMPUTACION', 3),
('FPP-M', 'Fundamentos de Programacion', 11, 'COMPUTACION', 2),
('GRI-M', 'Graficacion', 9, 'COMPUTACION', 8),
('IAE-M', 'Ingles Avanzado', 7, 'COMPUTACION', 6),
('IAI-M', 'Inteligencia Artificial', 10, 'COMPUTACION', 7),
('IBE-M', 'Ingles Basico', 7, 'COMPUTACION', 2),
('ICP-M', 'Introduccion a la Computacion', 8, 'COMPUTACION', 1),
('IEE-M', 'Ingles Elemental', 7, 'COMPUTACION', 3),
('IIE-M', 'Ingles Intermedio', 7, 'COMPUTACION', 5),
('IPE-M', 'Ingles Preintermedio', 7, 'COMPUTACION', 4),
('ISP-M', 'Ingenieria de Software', 11, 'COMPUTACION', 6),
('MAM-1M', 'Matematicas I', 10, 'COMPUTACION', 1),
('MAM-2M', 'Matematicas II', 10, 'COMPUTACION', 2),
('MAM-3M', 'Matematicas III', 10, 'COMPUTACION', 3),
('MDM-M', 'Matematicas Discretas', 10, 'COMPUTACION', 3),
('MIE-M', 'Metodologia de la Investigacion', 8, 'COMPUTACION', 6),
('OPT-1', 'Optativa I', 9, 'COMPUTACION', 7),
('OPT-2', 'Optativa II', 9, 'COMPUTACION', 7),
('OPT-3', 'Optativa III', 9, 'COMPUTACION', 8),
('OPT-4', 'Optativa IV', 9, 'COMPUTACION', 8),
('PEM-M', 'Probabilidad y Estadistica', 10, 'COMPUTACION', 4),
('PII-M', 'Procesamiento de Imagenes', 10, 'COMPUTACION', 7),
('PRP-1M', 'Programacion I', 11, 'COMPUTACION', 3),
('PRP-2M', 'Programacion II', 11, 'COMPUTACION', 4),
('PWP-M', 'Programacion Web', 11, 'COMPUTACION', 5),
('RCA-M', 'Redes de Computadoras', 10, 'COMPUTACION', 5),
('SDA-M', 'Sistemas Distribuidos', 10, 'COMPUTACION', 6),
('SIA-M', 'Seguridad Informatica', 11, 'COMPUTACION', 8),
('SOT-M', 'Sistemas Operativos', 9, 'COMPUTACION', 4),
('TAM-M', 'Teoria de Automatas y Lenguajes Formales', 10, 'COMPUTACION', 6);

-- --------------------------------------------------------

--
-- Table structure for table `materia_alumno`
--

CREATE TABLE `materia_alumno` (
  `Matricula_Alumno` int NOT NULL,
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Estado_Materia` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Calificacion` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `materia_alumno`
--

INSERT INTO `materia_alumno` (`Matricula_Alumno`, `Matricula_Materia`, `Estado_Materia`, `Calificacion`) VALUES
(93963, 'ALM-M', 'CURSANDO', 0),
(93963, 'COE-M', 'APROBADO', 8),
(93963, 'DSE-M', 'CURSANDO', 0),
(93963, 'EDM-M', 'RECURSANDO', 8),
(93963, 'FPP-M', 'CURSANDO', 0),
(93963, 'IBE-M', 'CURSANDO', 6),
(93963, 'ICP-M', 'APROBADO', 10),
(93963, 'IEE-M', 'CURSANDO', 0),
(93963, 'MAM-1M', 'RECURSANDO', 6),
(52743, 'MAM-1M', 'CURSANDO', 0),
(52743, 'DSE-M', 'CURSANDO', 0),
(52743, 'ALM-M', 'CURSANDO', 0);

-- --------------------------------------------------------

--
-- Table structure for table `materia_docente`
--

CREATE TABLE `materia_docente` (
  `Id_Docente` int NOT NULL,
  `Matricula_Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `materia_docente`
--

INSERT INTO `materia_docente` (`Id_Docente`, `Matricula_Materia`) VALUES
(1, 'BAT-M'),
(1, 'BDT-M'),
(1, 'FBT-M'),
(2, 'FPP-M'),
(2, 'PRP-1M');

-- --------------------------------------------------------

--
-- Table structure for table `requisito_materias`
--

CREATE TABLE `requisito_materias` (
  `Materia` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Requisito_Obligatorio` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `requisito_materias`
--

INSERT INTO `requisito_materias` (`Materia`, `Requisito_Obligatorio`) VALUES
('MAM-2M', 'MAM-1M'),
('MAM-3M', 'MAM-2M'),
('MDM-M', 'EDM-M'),
('AAM-M', 'FPP-M'),
('FBT-M', 'FPP-M'),
('BAT-M', 'FBT-M'),
('BDT-M', 'BAT-M'),
('COT-M', 'TAM-M'),
('FPP-M', 'ICP-M'),
('PRP-1M', 'FPP-M'),
('PRP-2M', 'FPP-M'),
('PWP-M', 'BAT-M'),
('PWP-M', 'FPP-M'),
('ISP-M', 'BAT-M'),
('ISP-M', 'PWP-M'),
('EDP-M', 'FPP-M'),
('EDA-M', 'CEA-M'),
('ACA-M', 'EDA-M'),
('SDA-M', 'RCA-M'),
('SDA-M', 'SOT-M'),
('SIA-M', 'RCA-M'),
('MIE-M', 'COE-M');

-- --------------------------------------------------------

--
-- Table structure for table `secretaria`
--

CREATE TABLE `secretaria` (
  `Numero_Empleado` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Nombre` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_P` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Apellido_M` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temporal_calif`
--

CREATE TABLE `temporal_calif` (
  `Id_Temp` int NOT NULL,
  `Matricula_Alum` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Calificacion` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Comentarios` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Id_grupo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `temporal_calif`
--

INSERT INTO `temporal_calif` (`Id_Temp`, `Matricula_Alum`, `Calificacion`, `Comentarios`, `Id_grupo`) VALUES
(1, '93963', '2', '', 2),
(2, '47856', '7', '', 2),
(3, '85639', '5', '', 2),
(4, '52863', '7', '', 2),
(5, '52743', '4', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `Id_usuario` int NOT NULL,
  `Usuario` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Password` varchar(130) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `Tipo_usuario` int NOT NULL,
  `Foto` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`Id_usuario`, `Usuario`, `Password`, `Tipo_usuario`, `Foto`) VALUES
(1, '93963', '$2y$10$WsOnCQHlqaeeA4n3teJdKuM9.xC9YCE6iOzU123p8WclUvRRoOYFG', 2, 'FB_IMG_1454518684191.jpg'),
(2, 'admin', '$2y$10$C4AyjNhAW/m7/4BUvIl.R.in76Q8DrYG/HX/YdcUKmwLj8zYtT7ya', 1, 'images.jpg'),
(3, 'secretaria', '$2y$10$nm2WXE80tvQ4urxCOVuYxO0l8PLtv/bRlbD9qGyIHoaAIL43AkybO', 3, NULL),
(7, '52743', '$2y$10$3EtCKXmhuZXk50Je80p5AOiNDRHQMeVGxLFgqcbkRqsuo6XF9ofQu', 2, NULL),
(8, '1', '$2y$10$LVkYNRHVD8F14H9ul4y0COs6Brw09O33Fu7gCvydiGdIVKrfmkRYK', 4, NULL),
(9, '2', '$2y$10$Ne63nUIgzNrc1bW1wXa0D.HoJLzu2tk3wR/IXTKChzH8o.OPbPWlq', 4, NULL),
(10, '47856', '$2y$10$DF56L1Xs4z9QSh718xxvWO1xD7iwnw1.kM2dHVE/u.GjZV4QofCTy', 2, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`Matricula_Alumno`);

--
-- Indexes for table `aulas`
--
ALTER TABLE `aulas`
  ADD PRIMARY KEY (`Id_Aula`);

--
-- Indexes for table `control_semestre`
--
ALTER TABLE `control_semestre`
  ADD PRIMARY KEY (`Id_semestre`);

--
-- Indexes for table `docente`
--
ALTER TABLE `docente`
  ADD PRIMARY KEY (`Id_Docente`);

--
-- Indexes for table `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`Id_grupo`);

--
-- Indexes for table `kardex_alumno`
--
ALTER TABLE `kardex_alumno`
  ADD PRIMARY KEY (`Id_kardex`);

--
-- Indexes for table `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`Matricula_Materia`);

--
-- Indexes for table `secretaria`
--
ALTER TABLE `secretaria`
  ADD PRIMARY KEY (`Numero_Empleado`);

--
-- Indexes for table `temporal_calif`
--
ALTER TABLE `temporal_calif`
  ADD PRIMARY KEY (`Id_Temp`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Id_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aulas`
--
ALTER TABLE `aulas`
  MODIFY `Id_Aula` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kardex_alumno`
--
ALTER TABLE `kardex_alumno`
  MODIFY `Id_kardex` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `temporal_calif`
--
ALTER TABLE `temporal_calif`
  MODIFY `Id_Temp` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Id_usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
